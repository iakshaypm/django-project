def prefix_line_numbers(code: str) -> str:
    # Split the code into lines
    lines = code.split('\n')

    # Prefix each line with the line number
    lines_with_numbers = [f"{i + 1} {line}" for i, line in enumerate(lines)]

    # Join the lines back into a single string
    return '\n'.join(lines_with_numbers)