def create_github_mr_note(mr_note_params):
    """
    Creates Merge Request Comment on github
    :param mr_note_params:
    :return:
    """
    merge_request_object = mr_note_params.get('merge_request_object')
    line_nos = mr_note_params.get('line_numbers')
    notes = mr_note_params.get('notes')
    file_path = mr_note_params.get('path')
    # Function to create Merge Request Note
    for line_no, note in zip(line_nos, notes):
        try:
            merge_request_object.create_review(
                body=" ",
                event="COMMENT",
                comments=[
                    {
                        "path": file_path,  # File path relative to the repository
                        "position": int(line_no),  # Position in the diff (not absolute line number)
                        "body": note,  # Inline comment body
                    }
                ],
            )
        except Exception as e:
            print(f"Error creating Merge Request Note: {e}")
            # logger.error(f"{messages.comment_error}, {e}")
