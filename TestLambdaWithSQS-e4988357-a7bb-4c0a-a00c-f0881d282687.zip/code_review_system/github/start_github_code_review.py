from code_review_system.add_line_number import prefix_line_numbers
from code_review_system.code_review_output import set_note_template, blank_file_note_format
from code_review_system.llm.llm_manager import LLMManager
from code_review_system.llm.code_review.output_parser import CodeReviewResult
from langchain_core.exceptions import OutputParserException
from code_review_system.github.create_github_mr_note import create_github_mr_note

def start_github_code_review(repo_params, llm_manager_object, code_review_chain):
    """
    Function to initiate GitHub code review
    :param repo_params: Dictionary containing repository parameters
    :param llm_manager_object: LLM manager instance
    :param code_review_chain: Chain for code review
    :param quality_analysis_chain: Chain for quality analysis
    :return: None
    """
    # git_manager_object = VCSManager()
    changes = repo_params.get('changes')
    project_object = repo_params.get('project_object')
    commit = repo_params.get('commit_message')
    merge_request_object = repo_params.get('merge_request_object')
    head_sha = merge_request_object.head.sha
    is_vulnerability_enabled = repo_params.get('is_vulnerability_test_enabled')
    source_branch = merge_request_object.head.ref
    # code_review_comment = "### Vulnerability Report\n\n"
    for change in changes:
        path = change.filename
        if change.status != "removed" and path not in repo_params.get('ignored_files'):
            try:
                code = project_object.get_contents(change.filename, ref=source_branch)
                decoded_code = code.decoded_content.decode('utf-8')

                if decoded_code.strip() == "":
                    code_review_comment += blank_file_note_format(path)
                    continue

                lined_code = prefix_line_numbers(decoded_code)

                llm_response = LLMManager().model_invoke(
                    code_review_chain,
                    {
                        "code": lined_code,
                        "branch": source_branch,
                        "commit": commit,
                    })
                # logger.info(messages.code_pass_to_llm_message)

                #Handle both Pydantic v1 and v2 methods
                if isinstance(llm_response, CodeReviewResult):
                    try:
                        # Try Pydantic v2 method first
                        response_dict = llm_response.dict()
                    except AttributeError:
                        try:
                            # Fall back to Pydantic v1 method
                            response_dict = llm_response.dict()
                        except AttributeError:
                            # If neither method exists, assume it's already a dict
                            response_dict = llm_response
                else:
                    response_dict = llm_response

                comments_data = response_dict.get('comments', [])

                # Process comments based on whether it's a list or dict
                if isinstance(comments_data, dict):
                    result = [set_note_template(str(line_no), comment, path)
                              for line_no, comment in comments_data.items()]
                elif isinstance(comments_data, list):
                    result = [set_note_template(str(item['line']), item['review'], path)
                              for item in comments_data]
                else:
                    print(f"Unexpected comments_data type: {type(comments_data)}")
                    # logger.error(f"Unexpected comments_data type: {type(comments_data)}")
                    continue

                if result:  # Check if we have any results
                    notes, line_numbers = zip(*result)
                    mr_note_params = {
                        'merge_request_object': merge_request_object,
                        'line_numbers': line_numbers,
                        'notes': notes,
                        'path': path,
                        'head_sha': head_sha
                    }

                    # if is_vulnerability_enabled:
                    #     try:
                    #         code_review_comment += f"\n### Vulnerability Scanned Report for {path}\n\n"
                    #         code_review_comment += await quality_analysis_report(
                    #             decoded_code,
                    #             path,
                    #             repo_params.get('model_preference'),
                    #             quality_analysis_chain
                    #         )
                    #         logger.info(f"{messages.added_vulnerability_note}")
                    #     except Exception as e:
                    #         logger.error(f"{messages.error_on_added_vulnerability_note}: {e}")

                create_github_mr_note(mr_note_params)

            except OutputParserException as e:
                print(f'{e}, path: {path}')
                # logger.error(f'{messages.output_parser_exception}, path: {path}')
                continue
            except Exception as e:
                print(f"Unexpected error processing {path}: {str(e)}")
                # logger.error(f"Unexpected error processing {path}: {str(e)}")
                continue
        else:
            print(f'file have been ignored {path}')
            # logger.info(f'file have been ignored {path}')

    # if is_vulnerability_enabled:
    #     await git_manager_object.mr_note_vulnerability(
    #         constants.GITHUB,
    #         merge_request_object,
    #         code_review_comment
    #     )
