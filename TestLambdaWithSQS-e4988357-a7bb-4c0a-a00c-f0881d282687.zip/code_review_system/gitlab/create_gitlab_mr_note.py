def create_gitlab_mr_note(mr_note_params):
    """
    Creates merge request note on gitlab
    :param mr_note_params:
    :return:
    """
    line_nos = mr_note_params.get('line_numbers')
    notes = mr_note_params.get('notes')
    merge_request_object = mr_note_params.get('merge_request_object')
    file_path = mr_note_params.get('path')
    start_sha = mr_note_params.get('source_sha')
    base_sha = mr_note_params.get('base_sha')
    head_sha = mr_note_params.get('head_sha')
    # Function to create Merge Request Note
    for line_no, note in zip(line_nos, notes):
        line_code = f"{start_sha}:{line_no}"
        try:
            merge_request_object.discussions.create({'body': note,
                                                     'position': {
                                                         'new_path': file_path,
                                                         'new_line': line_no,
                                                         'position_type': 'text',
                                                         'base_sha': base_sha,
                                                         'start_sha': start_sha,
                                                         'head_sha': head_sha
                                                     },
                                                'line_code': line_code
                                                     })
        except Exception as e:
            logger.error(f"{messages.comment_error} {e}, {file_path} : {line_no}")
