import base64

from code_review_system.add_line_number import prefix_line_numbers
from code_review_system.code_review_output import set_note_template, blank_file_note_format
from code_review_system.llm.llm_manager import LLMManager
from code_review_system.llm.code_review.output_parser import CodeReviewResult
from langchain_core.exceptions import OutputParserException
from code_review_system.gitlab.create_gitlab_mr_note import create_gitlab_mr_note
from code_review_system.vcs.vcs_manager import VCSManager

def start_gitlab_code_review(repo_params, llm_manager_object, code_review_chain):
    """
    Function to initiate gitlab code review
    :param repo_params:
    :param llm_manager_object:
    :param code_review_chain:
    :param quality_analysis_chain:
    :return:
    """
    # git_manager_object = VCSManager()
    changes = repo_params.get('changes')
    project_object = repo_params.get('project_object')
    commit = repo_params.get('commit_message')
    if repo_params.get('provider') == "gitlab":
        project_object = VCSManager().get_project_object(url_instance=repo_params.get('url_instance'),
                                                               project_id=project_object.id,
                                                               access_token=os.getenv('GITLAB_KEY'),
                                                               token_type="private_token")
        merge_request_object = (VCSManager().get_merge_request_object
                                       (project_object=project_object,
                                        merge_request_id=repo_params.get('merge_request_object').iid))
    else:
        merge_request_object = repo_params.get('merge_request_object')
    
    is_vulnerability_test_enabled = repo_params.get('is_vulnerability_test_enabled')
    source_branch = changes.get('source_branch')
    source_sha = changes.get('diff_refs').get('start_sha')
    base_sha = changes.get('diff_refs').get('base_sha')
    head_sha = changes.get('diff_refs').get('head_sha')
    # logger.info(messages.received_source_branch_message)
    # code_review_comment = "### Vulnerability Report\n\n"
    if not repo_params.get('ignore_files'):
        repo_params['ignore_files'] = []
    responses, codes, paths = [], [], []
    for change in changes['changes']:
        path = change.get('new_path')
        # Check if the file is not deleted and is not in the ignore list
        if not change.get('deleted_file') and path not in repo_params.get('ignored_files'):
            code = project_object.files.get(file_path=change.get('new_path'), ref=source_branch).content
            decoded_code = base64.b64decode(code).decode('utf-8')
            if decoded_code.strip() == "":
                code_review_comment += blank_file_note_format(path)
            else:
                # Get the code with line number
                lined_code = prefix_line_numbers(decoded_code)
                paths.append(path)
                codes.append(lined_code)
                try:
                    llm_response = LLMManager().model_invoke(
                        code_review_chain,
                        {
                            "code": lined_code,
                            "branch": source_branch,
                            "commit": commit,
                        })
                    # logger.info(messages.code_pass_to_llm_message)
                    #Check the response is of dictionary
                    if isinstance(llm_response, CodeReviewResult):
                        # Convert Pydantic model to dictionary
                        response_dict = llm_response.dict()
                        comments_data = response_dict.get('comments', {})
                    else:
                        comments_data = llm_response.get('comments', {})

                    result = map(lambda item: set_note_template(item[0], item[1], path),
                                 comments_data.items())
                    notes, line_numbers = zip(*result)
                    mr_note_params = {
                        'project_id': project_object.id,
                        'merge_request_object': merge_request_object,
                        'line_numbers' : line_numbers,
                        'notes' : notes,
                        'path' : path,
                        'source_sha' : source_sha,
                        'base_sha' : base_sha,
                        'head_sha' : head_sha
                    }

                    # Check the vulnerability is On/ Off
                    # if is_vulnerability_test_enabled:
                    #     try:
                    #         code_review_comment += "\n\n#### Vulnerability Scanned Report for " + path + "\n\n"
                    #         code_review_comment += await quality_analysis_report(decoded_code, path,
                    #                                                        repo_params.get('model_preference'),
                    #                                                        quality_analysis_chain)
                    #         logger.info(f"{messages.added_vulnerability_note}")
                    #     except Exception as e:
                    #         logger.error(f"{messages.error_on_added_vulnerability_note}: {e}")
                    create_gitlab_mr_note(mr_note_params)
                except OutputParserException as e:
                    print(f'{e}, path: {path}')
                    # logger.error(f'{messages.output_parser_exception}, path: {path}')
                    continue
        else:
            logger.info(f'file have been ignored {path}')
    # if is_vulnerability_test_enabled:
    #     await git_manager_object.mr_note_vulnerability(constants.GITLAB, merge_request_object,
    #                                                     code_review_comment)
