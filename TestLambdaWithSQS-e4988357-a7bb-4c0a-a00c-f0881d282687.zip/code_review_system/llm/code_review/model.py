import os
import langchain
from langchain_openai import ChatOpenAI

# Optionally, you can still call load_dotenv() locally for testing
# But in Lambda, environment variables are already set
# from dotenv import load_dotenv
# load_dotenv()

langchain.debug = True

# Retrieve environment variables
openai_api_key = os.environ.get("OPENAI_API_KEY")
# You could also retrieve the model name, temperature, etc. if needed:
model_name = os.environ.get("MODEL_NAME", "gpt-4o")  # Default to 'gpt-4o' if not provided

# Create your ChatOpenAI instance, passing the environment variable(s)
llm = ChatOpenAI(
    openai_api_key=openai_api_key,
    temperature=0.5,
    max_tokens=None,
    timeout=None,
    max_retries=3,
    model=model_name
)

# Now you can use 'llm' in your Lambda function
