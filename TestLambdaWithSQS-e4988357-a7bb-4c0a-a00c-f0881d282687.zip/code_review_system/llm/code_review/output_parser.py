from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.pydantic_v1 import BaseModel, Field
from typing import Dict, Union, List

class ErrorDetail(BaseModel):
    """Parser validation for error description"""
    issue: str = Field(description="Title of the identified issue")
    review: str = Field(description="Detailed explanation of the identified issue")
    suggestion: str = Field(description="Recommended code revision or solution by rewriting the code")
    code: str = Field(description="Rewrite the resolved code")


class CodeReviewResult(BaseModel):
    """Parser validation for code review results"""
    comments: Union[
        Dict[int, ErrorDetail],
        List[Dict[str, Union[int, str]]]
    ] = Field(..., description="Code review comments in either dictionary or list format")

    commit_message_evaluation: str = Field(...)
    branch_name_evaluation: str = Field(...)

# Initialize the JsonOutputParser with the modified CodeReviewResult schema
code_review_output_parser = PydanticOutputParser(pydantic_object=CodeReviewResult)