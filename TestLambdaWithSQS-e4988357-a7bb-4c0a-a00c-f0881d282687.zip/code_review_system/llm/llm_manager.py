from typing import Dict, Any

from langchain.chains.base import Chain
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda

from .code_review.output_parser import CodeReviewResult
# from code_review_system.llm.quality_analysis.output_parser import ToolName
# from code_review_system.utils.log_manager import logger
# from constants import messages, constants


class LLMManager:

    def get_prompt_template(self, prompt):
        """
        Convert string to PromptTemplate
        :param prompt:
        :return:
        """
        prompt_template = PromptTemplate(template=prompt)
        return prompt_template

    def get_chain(self, args_arr):
        """
        Create a Chain with the provided inputs
        """
        chain = args_arr.pop(0)
        for item in args_arr:
            chain = chain | item
        return chain

    def batch_invoke(self, chain: Chain, prompt_params) -> [dict]:
        """
        Asynchronously batch invoke the chain
        :param chain:
        :param prompt_params:
        :return:
        """
        return chain.batch(prompt_params)

    def model_invoke(self, chain: Chain, prompt_params) -> [dict]:
        """
        Asynchronously invoke the chain
        :param chain:
        :param prompt_params:
        :return:
        """
        return chain.invoke(prompt_params)
