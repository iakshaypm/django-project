import gitlab
# from dotenv import load_dotenv

# from constants import constants

# load_dotenv()

class VCSManager:
    def get_project_object(self, url_instance, project_id, access_token, token_type):
        """
        Get the project object for initiating Code Review

        :param  :    url_instance: url of the vcs
                    project_id: project_id of the project
                    access_token:   access_token to get the project

        .. versionadded:: 0.1.0

        :return : project_object
        """
        if token_type == "oauth_token":
            gitlab_object = gitlab.Gitlab(url=url_instance, oauth_token=access_token)
        else:
            gitlab_object = gitlab.Gitlab(url=url_instance, private_token=access_token)
        project_object = gitlab_object.projects.get(project_id)
        return project_object

    def get_merge_request_object(self, project_object, merge_request_id):
        """ function to return merge request object """
        merge_request_object = project_object.mergerequests.get(id=merge_request_id)
        return merge_request_object

    def get_mr_changes(self, merge_request_object):
        """function to return changes in the mr"""
        changes = merge_request_object.changes()
        return changes


    def mr_note_vulnerability(self, provider, merge_request_object, report):
        if provider == "gitlab":
            merge_request_object.notes.create({'body':report})
        if provider == "github":
            merge_request_object.create_issue_comment(report)







