import json
from github import Github
from gitlab import GitlabAuthenticationError
from code_review_system.llm.llm_manager import LLMManager
from code_review_system.llm.code_review.model import llm
from code_review_system.llm.code_review.prompt import prompt as code_review_prompt
from code_review_system.llm.code_review.output_parser import code_review_output_parser
from code_review_system.llm.code_review.output_parser import CodeReviewResult
from code_review_system.github.start_github_code_review import start_github_code_review
from code_review_system.gitlab.start_gitlab_code_review import start_gitlab_code_review
from code_review_system.vcs.vcs_manager import VCSManager
from langchain.globals import set_debug

# Turn off debug mode
set_debug(False)


def lambda_handler(event, context):
    print(event)

    git_object = VCSManager()

    records = event['Records']

    for record in records:
        data = json.loads(record['body'])
        
        params = data.get('repo_params', data)
        provider = data.get('provider', data)

        project_id = params.get('project_id')
        merge_request_id = params.get('merge_request_id')
        access_token = params.get('access_token')
        ignored_files = params.get('ignored_files')


        result = {}
        
        required_keys = ['access_token', 'project_id', 'merge_request_id']
        if not all(key in params for key in required_keys):
            print("Missing required keys in the message:", params)
            continue

        if provider == 'github':

            github_instance = Github(access_token)
            
            project_object = github_instance.get_repo(project_id)
            
            merge_request_object = project_object.get_pull(merge_request_id)
            
            commits = list(merge_request_object.get_commits())
            if not commits:
                print("No commits found in the merge request")
                continue
            last_commit = commits[-1]
            commit_message = last_commit.commit.message
            
            changes = list(merge_request_object.get_files())
        
            result = {
                'project_object': project_object,
                'merge_request_object': merge_request_object,
                'commit_message': commit_message,
                'changes': changes,
                'model_preference': params.get('model_preference'),
                'is_vulnerability_test_enabled': params.get('is_vulnerability_test_enabled'),
                'ignored_files': ignored_files
            }

            # print(type(project_object), type(merge_request_object), type(commit_message), type(changes), type(result))
        
        else:

            try:
                project_object = git_object.get_project_object(params.get("url_instance"), project_id, access_token, "oauth_token")

                if project_object:
                    try:
                        merge_request_object = git_object.get_merge_request_object(project_object, merge_request_id)
                    except Exception as e:
                        print("Exception at merge_request_object", e)
                    changes = git_object.get_mr_changes(merge_request_object)

                    result = {
                        'project_object': project_object,
                        'merge_request_object': merge_request_object,
                        'commit_message': params.get('commit_message'),
                        'changes': changes,
                        'model_preference': params.get('model_preference'),
                        'is_vulnerability_test_enabled': params.get('is_vulnerability_test_enabled'),
                        'ignored_files': ignored_files
                    }

            except GitlabAuthenticationError:
                print("Authentication error")
            except Exception as e:
                print(e)
        
        # print(result)

        initiate_code_review(provider, result)


def initiate_code_review(provider, repo_params):
    """ function to initiate code review """


    try:
        # Validate repo_params is a dict and has required fields
        if not isinstance(repo_params, dict):
            # logger.error("Invalid repo_params type: expected dict")
            return

        llm_manager_object = LLMManager()
        model_preference = repo_params.get('model_preference')

        if not model_preference:
            # logger.error("Missing model_preference in repo_params")
            return

        # if model_preference in [ModelType.Mistral, ModelType.Codellama]:
        #     remote_llm = RemoteLLM(
        #         model_name=model_preference.value,
        #         timeout=100
        #     )
        #     model = remote_llm
        # else:
        model = llm

        structured_llm = model.with_structured_output(
            CodeReviewResult,
        )

        code_review_chain = llm_manager_object.get_chain([
            llm_manager_object.get_prompt_template(code_review_prompt),
            structured_llm
        ])

        # quality_analysis_chain = get_quality_analysis_llm_chain(model_preference)
        # logger.info(messages.chain_creation_message)

        if provider in ["gitlab", "qburst"]:
            start_gitlab_code_review(repo_params, llm_manager_object, code_review_chain)
        elif provider == "github":
            start_github_code_review(repo_params, llm_manager_object, code_review_chain)

    except Exception as e:
        print(e)
        # logger.error(f"Error in initiate_code_review: {str(e)}")
        raise     
