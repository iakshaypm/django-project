var 0004__room__type_8py =
[
    [ "chat.migrations.0004_room_type.Migration", "classchat_1_1migrations_1_10004__room__type_1_1Migration.html", "classchat_1_1migrations_1_10004__room__type_1_1Migration" ]
];