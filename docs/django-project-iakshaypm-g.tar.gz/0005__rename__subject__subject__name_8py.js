var 0005__rename__subject__subject__name_8py =
[
    [ "user.migrations.0005_rename_subject_subject_name.Migration", "classuser_1_1migrations_1_10005__rename__subject__subject__name_1_1Migration.html", "classuser_1_1migrations_1_10005__rename__subject__subject__name_1_1Migration" ]
];