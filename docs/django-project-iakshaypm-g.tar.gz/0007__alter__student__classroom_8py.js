var 0007__alter__student__classroom_8py =
[
    [ "user.migrations.0007_alter_student_classroom.Migration", "classuser_1_1migrations_1_10007__alter__student__classroom_1_1Migration.html", "classuser_1_1migrations_1_10007__alter__student__classroom_1_1Migration" ]
];