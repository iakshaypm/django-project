var 0008__alter__student__classroom_8py =
[
    [ "user.migrations.0008_alter_student_classroom.Migration", "classuser_1_1migrations_1_10008__alter__student__classroom_1_1Migration.html", "classuser_1_1migrations_1_10008__alter__student__classroom_1_1Migration" ]
];