var 0008__mainattendance__classroom_8py =
[
    [ "attendance.migrations.0008_mainattendance_classroom.Migration", "classattendance_1_1migrations_1_10008__mainattendance__classroom_1_1Migration.html", "classattendance_1_1migrations_1_10008__mainattendance__classroom_1_1Migration" ]
];