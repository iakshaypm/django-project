var assignment_2models_8py =
[
    [ "assignment.models.Assignment", "classassignment_1_1models_1_1Assignment.html", "classassignment_1_1models_1_1Assignment" ],
    [ "assignment.models.Assignment.Meta", "classassignment_1_1models_1_1Assignment_1_1Meta.html", "classassignment_1_1models_1_1Assignment_1_1Meta" ],
    [ "assignment.models.AssignmentMark", "classassignment_1_1models_1_1AssignmentMark.html", "classassignment_1_1models_1_1AssignmentMark" ],
    [ "assignment.models.AssignmentMark.Meta", "classassignment_1_1models_1_1AssignmentMark_1_1Meta.html", "classassignment_1_1models_1_1AssignmentMark_1_1Meta" ]
];