var assignment_2urls_8py =
[
    [ "app_name", "assignment_2urls_8py.html#a187bdf6b70304a9837b4a5564826b7d1", null ],
    [ "urlpatterns", "assignment_2urls_8py.html#a6674b6558998acf77c6412e5d9eaebe9", null ]
];