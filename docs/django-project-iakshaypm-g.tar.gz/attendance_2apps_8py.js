var attendance_2apps_8py =
[
    [ "attendance.apps.AttendanceConfig", "classattendance_1_1apps_1_1AttendanceConfig.html", "classattendance_1_1apps_1_1AttendanceConfig" ]
];