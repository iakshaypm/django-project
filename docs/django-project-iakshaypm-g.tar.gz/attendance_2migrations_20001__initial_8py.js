var attendance_2migrations_20001__initial_8py =
[
    [ "attendance.migrations.0001_initial.Migration", "classattendance_1_1migrations_1_10001__initial_1_1Migration.html", "classattendance_1_1migrations_1_10001__initial_1_1Migration" ]
];