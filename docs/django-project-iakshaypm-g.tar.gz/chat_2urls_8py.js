var chat_2urls_8py =
[
    [ "urlpatterns", "chat_2urls_8py.html#ab6d985bded5220bb026e4afc78244ec3", null ]
];