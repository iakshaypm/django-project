var classassignment_1_1apps_1_1AssignmentConfig =
[
    [ "default_auto_field", "classassignment_1_1apps_1_1AssignmentConfig.html#a983c04ad2a5d371af381b7b40f1cbae2", null ],
    [ "name", "classassignment_1_1apps_1_1AssignmentConfig.html#a5fd25a672b72bcc74cf009b745dd386b", null ]
];