var classassignment_1_1migrations_1_10001__initial_1_1Migration =
[
    [ "dependencies", "classassignment_1_1migrations_1_10001__initial_1_1Migration.html#a24bf0856e0c848fd625737ff39148ef5", null ],
    [ "initial", "classassignment_1_1migrations_1_10001__initial_1_1Migration.html#ac388479294394bdf9b8df0ac123dcfbc", null ],
    [ "operations", "classassignment_1_1migrations_1_10001__initial_1_1Migration.html#a4fb4412682dc56ab022aed0c3310bd49", null ]
];