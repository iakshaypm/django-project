var classassignment_1_1models_1_1AssignmentMark =
[
    [ "Meta", "classassignment_1_1models_1_1AssignmentMark_1_1Meta.html", "classassignment_1_1models_1_1AssignmentMark_1_1Meta" ],
    [ "assignment", "classassignment_1_1models_1_1AssignmentMark.html#adf588eda31e348e34447b46d4fbc13a4", null ],
    [ "mark", "classassignment_1_1models_1_1AssignmentMark.html#a0ca11d1161ac7f8a6c9e2623141907ab", null ]
];