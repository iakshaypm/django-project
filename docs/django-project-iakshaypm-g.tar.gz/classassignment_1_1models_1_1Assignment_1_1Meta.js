var classassignment_1_1models_1_1Assignment_1_1Meta =
[
    [ "db_table", "classassignment_1_1models_1_1Assignment_1_1Meta.html#a40b145bf40869dc918ae613028e8aae4", null ]
];