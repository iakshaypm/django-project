var classassignment_1_1serializers_1_1AssignmentMarkSerializer_1_1Meta =
[
    [ "fields", "classassignment_1_1serializers_1_1AssignmentMarkSerializer_1_1Meta.html#ad5f4b33c2ba85bd2a1abcb5e2bed18d5", null ],
    [ "model", "classassignment_1_1serializers_1_1AssignmentMarkSerializer_1_1Meta.html#a42a0f31b38a0d32a48cdeb87f441386b", null ]
];