var classattendance_1_1apps_1_1AttendanceConfig =
[
    [ "default_auto_field", "classattendance_1_1apps_1_1AttendanceConfig.html#ae9ece974ea73e0e17997ac1b4d265a99", null ],
    [ "name", "classattendance_1_1apps_1_1AttendanceConfig.html#a80a583489900de6d16af160c63bbfb70", null ]
];