var classattendance_1_1migrations_1_10001__initial_1_1Migration =
[
    [ "dependencies", "classattendance_1_1migrations_1_10001__initial_1_1Migration.html#a50da3cd4c840aa76fa1b4a8d36f1014b", null ],
    [ "initial", "classattendance_1_1migrations_1_10001__initial_1_1Migration.html#a9f2fc5eaba56411a7d8c2b7b99d13531", null ],
    [ "operations", "classattendance_1_1migrations_1_10001__initial_1_1Migration.html#a78b3d3616c8f223a5a91e987138927f4", null ]
];