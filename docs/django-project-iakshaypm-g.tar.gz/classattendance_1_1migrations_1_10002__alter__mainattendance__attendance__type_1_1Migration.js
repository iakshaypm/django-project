var classattendance_1_1migrations_1_10002__alter__mainattendance__attendance__type_1_1Migration =
[
    [ "dependencies", "classattendance_1_1migrations_1_10002__alter__mainattendance__attendance__type_1_1Migration.html#aef8f706ed3aa663f6afdac956f4f49a3", null ],
    [ "operations", "classattendance_1_1migrations_1_10002__alter__mainattendance__attendance__type_1_1Migration.html#ac34bf27ab2da361fd8f1de0be753931f", null ]
];