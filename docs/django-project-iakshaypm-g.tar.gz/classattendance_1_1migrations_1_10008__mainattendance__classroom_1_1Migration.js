var classattendance_1_1migrations_1_10008__mainattendance__classroom_1_1Migration =
[
    [ "dependencies", "classattendance_1_1migrations_1_10008__mainattendance__classroom_1_1Migration.html#a68aeb728a84f51d2a2885c9b9cb804b0", null ],
    [ "operations", "classattendance_1_1migrations_1_10008__mainattendance__classroom_1_1Migration.html#a5fa450425036123051467ba74aa9057d", null ]
];