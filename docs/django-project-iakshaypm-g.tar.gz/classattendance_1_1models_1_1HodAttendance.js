var classattendance_1_1models_1_1HodAttendance =
[
    [ "Meta", "classattendance_1_1models_1_1HodAttendance_1_1Meta.html", "classattendance_1_1models_1_1HodAttendance_1_1Meta" ],
    [ "attendance", "classattendance_1_1models_1_1HodAttendance.html#a7e35036d1557df955c92161f9a4aa0df", null ],
    [ "date_of_marking", "classattendance_1_1models_1_1HodAttendance.html#a1112825633bc314618462c4e9658bb11", null ],
    [ "hod", "classattendance_1_1models_1_1HodAttendance.html#a694a75b97c55ba8b4e3169c7a4900764", null ]
];