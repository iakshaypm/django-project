var classattendance_1_1models_1_1HodAttendance_1_1Meta =
[
    [ "db_table", "classattendance_1_1models_1_1HodAttendance_1_1Meta.html#a0bfc0b8f796349a697b69321de4cdc21", null ]
];