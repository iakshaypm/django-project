var classattendance_1_1models_1_1MainAttendance =
[
    [ "Meta", "classattendance_1_1models_1_1MainAttendance_1_1Meta.html", "classattendance_1_1models_1_1MainAttendance_1_1Meta" ],
    [ "attendance_type", "classattendance_1_1models_1_1MainAttendance.html#a0f34418ca2c9fca8b27e15684a5fe809", null ],
    [ "ATTENDANCE_TYPE_CHOOSES", "classattendance_1_1models_1_1MainAttendance.html#aa3932a5c79cd2779bbbc158c05c8d86f", null ],
    [ "classroom", "classattendance_1_1models_1_1MainAttendance.html#a2f4e7920cc969672a2f2b6c785d6a405", null ],
    [ "date_of_producing", "classattendance_1_1models_1_1MainAttendance.html#a6b8886c369b8283e7b45f3ba417d3757", null ],
    [ "initiated_by", "classattendance_1_1models_1_1MainAttendance.html#a069d73a17bd89c2a26f4d340fe173b0a", null ]
];