var classattendance_1_1models_1_1StudentAttendance =
[
    [ "Meta", "classattendance_1_1models_1_1StudentAttendance_1_1Meta.html", "classattendance_1_1models_1_1StudentAttendance_1_1Meta" ],
    [ "attendance", "classattendance_1_1models_1_1StudentAttendance.html#ae69d4618d5ed57805bd832b2fc1c8e27", null ],
    [ "date_of_marking", "classattendance_1_1models_1_1StudentAttendance.html#aa4db537c5cca2f32565fa0a4b84db801", null ],
    [ "student", "classattendance_1_1models_1_1StudentAttendance.html#af6b1b1f6f9e4610f579c8f305bc68ff0", null ]
];