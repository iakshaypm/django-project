var classattendance_1_1permission_1_1CanAddAttendance =
[
    [ "has_permission", "classattendance_1_1permission_1_1CanAddAttendance.html#a0baa0f36d5f3aa4b4c72117b68222f99", null ]
];