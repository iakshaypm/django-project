var classattendance_1_1serializer_1_1StudentAttendanceSerializer =
[
    [ "Meta", "classattendance_1_1serializer_1_1StudentAttendanceSerializer_1_1Meta.html", "classattendance_1_1serializer_1_1StudentAttendanceSerializer_1_1Meta" ],
    [ "validate_attendance_id", "classattendance_1_1serializer_1_1StudentAttendanceSerializer.html#a14a6a0f2844d3f47537ea6789b23b8bc", null ],
    [ "date_of_marking", "classattendance_1_1serializer_1_1StudentAttendanceSerializer.html#ab01621e0c7e6e1871be0816d14512674", null ],
    [ "id", "classattendance_1_1serializer_1_1StudentAttendanceSerializer.html#afaaeedb4f60e9b44e1cb1990c0813eb6", null ],
    [ "student", "classattendance_1_1serializer_1_1StudentAttendanceSerializer.html#af84cf4aa7bf5ba00516c9abdb500a5e4", null ]
];