var classattendance_1_1views_1_1AttendanceCreateView =
[
    [ "post", "classattendance_1_1views_1_1AttendanceCreateView.html#a97b1b96f67406f38f57f3531acced41f", null ],
    [ "permission_classes", "classattendance_1_1views_1_1AttendanceCreateView.html#a80737686a4b740ba075c0b02d334e336", null ],
    [ "serializer_class", "classattendance_1_1views_1_1AttendanceCreateView.html#a855972fb4de361c58a55abf55a73f0b9", null ]
];