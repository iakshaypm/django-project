var classattendance_1_1views_1_1ShowAttendanceView =
[
    [ "get_queryset", "classattendance_1_1views_1_1ShowAttendanceView.html#af6e650a3c652bca5e73144f8bd0a2cd4", null ],
    [ "permission_classes", "classattendance_1_1views_1_1ShowAttendanceView.html#a5b2b350ae54f42bce1df162ecdfe5e5e", null ],
    [ "serializer_class", "classattendance_1_1views_1_1ShowAttendanceView.html#a3e61d742ec56efa9859bc4ab53166fe3", null ]
];