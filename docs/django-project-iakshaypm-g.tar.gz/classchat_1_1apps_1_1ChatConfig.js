var classchat_1_1apps_1_1ChatConfig =
[
    [ "default_auto_field", "classchat_1_1apps_1_1ChatConfig.html#aaf4392f6d4df28b32e2f24dbbfce391d", null ],
    [ "name", "classchat_1_1apps_1_1ChatConfig.html#afe6da342041660b6127be4a8b40d0ed4", null ]
];