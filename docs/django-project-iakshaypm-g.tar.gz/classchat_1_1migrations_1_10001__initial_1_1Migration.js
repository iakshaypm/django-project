var classchat_1_1migrations_1_10001__initial_1_1Migration =
[
    [ "dependencies", "classchat_1_1migrations_1_10001__initial_1_1Migration.html#a91b2405b666e2e1ca5925177e9fd77e7", null ],
    [ "initial", "classchat_1_1migrations_1_10001__initial_1_1Migration.html#ad3d2b19b38134d3c5bfb82ccbd605ebb", null ],
    [ "operations", "classchat_1_1migrations_1_10001__initial_1_1Migration.html#a8021f6c02bf62aa61f7ee4a81fdae0b7", null ]
];