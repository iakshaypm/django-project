var classchat_1_1migrations_1_10003__room__created__by__alter__room__online_1_1Migration =
[
    [ "dependencies", "classchat_1_1migrations_1_10003__room__created__by__alter__room__online_1_1Migration.html#a84f3220690b3ee7896f6608a56c989c1", null ],
    [ "operations", "classchat_1_1migrations_1_10003__room__created__by__alter__room__online_1_1Migration.html#ab27076330cbc2fc515f910c424ea5d09", null ]
];