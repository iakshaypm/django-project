var classchat_1_1serializers_1_1RoomSerializer =
[
    [ "Meta", "classchat_1_1serializers_1_1RoomSerializer_1_1Meta.html", "classchat_1_1serializers_1_1RoomSerializer_1_1Meta" ]
];