var classchat_1_1serializers_1_1RoomSerializer_1_1Meta =
[
    [ "fields", "classchat_1_1serializers_1_1RoomSerializer_1_1Meta.html#ac81356c6821b29adc4791a8cbf8835a7", null ],
    [ "model", "classchat_1_1serializers_1_1RoomSerializer_1_1Meta.html#a4b817e60ebb442a90abfbcfa46f64acf", null ]
];