var classclassroom_1_1permission_1_1IsManagement =
[
    [ "has_permission", "classclassroom_1_1permission_1_1IsManagement.html#a29c8c906e28b632f937edddc1fd4ce88", null ]
];