var classclassroom_1_1serializers_1_1ClassroomSerializer =
[
    [ "Meta", "classclassroom_1_1serializers_1_1ClassroomSerializer_1_1Meta.html", "classclassroom_1_1serializers_1_1ClassroomSerializer_1_1Meta" ]
];