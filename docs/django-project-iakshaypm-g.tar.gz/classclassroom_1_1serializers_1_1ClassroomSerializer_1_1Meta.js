var classclassroom_1_1serializers_1_1ClassroomSerializer_1_1Meta =
[
    [ "fields", "classclassroom_1_1serializers_1_1ClassroomSerializer_1_1Meta.html#a028bc90d5a564173d59d9ee4502f80d7", null ],
    [ "model", "classclassroom_1_1serializers_1_1ClassroomSerializer_1_1Meta.html#ad3784250eb8a4a8dca10e687769d3d7f", null ]
];