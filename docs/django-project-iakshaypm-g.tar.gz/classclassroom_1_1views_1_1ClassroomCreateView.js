var classclassroom_1_1views_1_1ClassroomCreateView =
[
    [ "post", "classclassroom_1_1views_1_1ClassroomCreateView.html#a3edab260aa755d7b2115d0add7502ad9", null ],
    [ "permission_classes", "classclassroom_1_1views_1_1ClassroomCreateView.html#a57f9a2aedfa716f5e4981ec79854deec", null ]
];