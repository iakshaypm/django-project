var classexam_1_1serializers_1_1ExamSerializer_1_1Meta =
[
    [ "fields", "classexam_1_1serializers_1_1ExamSerializer_1_1Meta.html#a66a2754f1aa27072095223b5d76c9701", null ],
    [ "model", "classexam_1_1serializers_1_1ExamSerializer_1_1Meta.html#afc8b4bf523f24adac8275b3791b53b02", null ]
];