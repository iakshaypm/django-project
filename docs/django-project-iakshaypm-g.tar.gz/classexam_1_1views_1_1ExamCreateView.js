var classexam_1_1views_1_1ExamCreateView =
[
    [ "post", "classexam_1_1views_1_1ExamCreateView.html#a8004f8f477dbeb550650cd4c5c15d092", null ],
    [ "send_sms", "classexam_1_1views_1_1ExamCreateView.html#a6dc52a826f3efbd6df31607300e9cef2", null ],
    [ "permission_classes", "classexam_1_1views_1_1ExamCreateView.html#a0b8d2ec562babfe0e96f8a98711578f7", null ]
];