var classexchange_1_1models_1_1Comment =
[
    [ "content", "classexchange_1_1models_1_1Comment.html#a4b0624ac4c6c491050d1c397d311473d", null ],
    [ "question", "classexchange_1_1models_1_1Comment.html#aca35059939e1dc5e0c9f458a392f0138", null ],
    [ "user", "classexchange_1_1models_1_1Comment.html#a3c62a676af43b2fc9871eea78d289707", null ]
];