var classexchange_1_1models_1_1Question =
[
    [ "description", "classexchange_1_1models_1_1Question.html#aaed4ca4626fe5b76d0317961e0871904", null ],
    [ "tag", "classexchange_1_1models_1_1Question.html#a850b6440865a49b91b3da44ce9f1a5f4", null ],
    [ "title", "classexchange_1_1models_1_1Question.html#a50625eabad28b8a5a616b789f188b1b4", null ],
    [ "user", "classexchange_1_1models_1_1Question.html#a50ba64d9a80a9f370a29b30a4ef4511b", null ]
];