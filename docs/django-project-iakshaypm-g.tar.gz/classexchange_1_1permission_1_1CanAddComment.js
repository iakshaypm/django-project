var classexchange_1_1permission_1_1CanAddComment =
[
    [ "has_permission", "classexchange_1_1permission_1_1CanAddComment.html#a10b1e743b3690ed45b848fe148a11615", null ]
];