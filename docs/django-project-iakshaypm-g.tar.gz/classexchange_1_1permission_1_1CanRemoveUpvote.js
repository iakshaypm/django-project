var classexchange_1_1permission_1_1CanRemoveUpvote =
[
    [ "has_object_permission", "classexchange_1_1permission_1_1CanRemoveUpvote.html#a43a351659396e5095f260f9f06387a41", null ]
];