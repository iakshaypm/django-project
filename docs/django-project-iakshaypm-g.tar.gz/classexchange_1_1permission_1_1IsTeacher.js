var classexchange_1_1permission_1_1IsTeacher =
[
    [ "has_permission", "classexchange_1_1permission_1_1IsTeacher.html#a1d03149b70cec5d1d7c7352b4e9b26aa", null ]
];