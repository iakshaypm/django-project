var classexchange_1_1views_1_1CommentDeleteView =
[
    [ "delete", "classexchange_1_1views_1_1CommentDeleteView.html#ab0489dba05150618b917d342c7476cac", null ],
    [ "permission_classes", "classexchange_1_1views_1_1CommentDeleteView.html#ad974d8a019f599b19c8dc3d8f265ae2f", null ],
    [ "queryset", "classexchange_1_1views_1_1CommentDeleteView.html#ad007f7526507e11a64cbd99a3c3a3bb7", null ],
    [ "serializer_class", "classexchange_1_1views_1_1CommentDeleteView.html#a83af1e1974876a992d53d2bab7bb10bf", null ]
];