var classexchange_1_1views_1_1CommentListView =
[
    [ "permission_classes", "classexchange_1_1views_1_1CommentListView.html#ab1adfa6a94de5b9ca785e6650f42a1e3", null ],
    [ "queryset", "classexchange_1_1views_1_1CommentListView.html#a39a6417e1f74e7095c0456417d128f5f", null ],
    [ "serializer_class", "classexchange_1_1views_1_1CommentListView.html#af95547ee6bc07a189175e9eeb376edd3", null ]
];