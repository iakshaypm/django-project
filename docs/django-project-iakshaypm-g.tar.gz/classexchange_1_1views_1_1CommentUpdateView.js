var classexchange_1_1views_1_1CommentUpdateView =
[
    [ "permission_classes", "classexchange_1_1views_1_1CommentUpdateView.html#ab9b6d84497b57224505f0c6dcf251841", null ],
    [ "queryset", "classexchange_1_1views_1_1CommentUpdateView.html#a6b4b29b271e9f55db244556d35e28622", null ],
    [ "serializer_class", "classexchange_1_1views_1_1CommentUpdateView.html#a16e93ed554ca7ad604101adfa431a12c", null ]
];