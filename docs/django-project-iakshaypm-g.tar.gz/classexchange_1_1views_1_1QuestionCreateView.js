var classexchange_1_1views_1_1QuestionCreateView =
[
    [ "post", "classexchange_1_1views_1_1QuestionCreateView.html#a831f4ebfe760474cfed3674d18e000ee", null ],
    [ "permission_classes", "classexchange_1_1views_1_1QuestionCreateView.html#aa2fc7c7c7a3a221ce4cebf72cefb4386", null ]
];