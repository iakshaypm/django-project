var classexchange_1_1views_1_1QuestionDeleteView =
[
    [ "delete", "classexchange_1_1views_1_1QuestionDeleteView.html#ace3d5bdb2384a8a8c3535d1ef03a9918", null ],
    [ "permission_classes", "classexchange_1_1views_1_1QuestionDeleteView.html#a3b3274290f3ef730eb14062f906d02fa", null ],
    [ "queryset", "classexchange_1_1views_1_1QuestionDeleteView.html#a4ad26b160a3953f9994bbd78bfb58d13", null ],
    [ "serializer_class", "classexchange_1_1views_1_1QuestionDeleteView.html#a4a91d3df62f0d471195e4742f5b6f235", null ]
];