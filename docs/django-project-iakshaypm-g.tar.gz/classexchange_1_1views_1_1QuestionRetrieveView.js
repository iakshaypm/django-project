var classexchange_1_1views_1_1QuestionRetrieveView =
[
    [ "permission_classes", "classexchange_1_1views_1_1QuestionRetrieveView.html#aab1916cf954bf29d6c2101397e0f7f0b", null ],
    [ "queryset", "classexchange_1_1views_1_1QuestionRetrieveView.html#a299c699757310a98caf70c4fad82c40c", null ],
    [ "serializer_class", "classexchange_1_1views_1_1QuestionRetrieveView.html#abeac435a0c4951409b1bd5cf97449a97", null ]
];