var classgrade_1_1permission_1_1IsStudent =
[
    [ "has_object_permission", "classgrade_1_1permission_1_1IsStudent.html#a5265f4d38d1079d79a74aba0c22d1064", null ],
    [ "has_permission", "classgrade_1_1permission_1_1IsStudent.html#a2b983a8902c7642c6e823457ff730a3f", null ]
];