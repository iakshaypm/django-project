var classgrade_1_1serializer_1_1MarkSerializer =
[
    [ "Meta", "classgrade_1_1serializer_1_1MarkSerializer_1_1Meta.html", "classgrade_1_1serializer_1_1MarkSerializer_1_1Meta" ]
];