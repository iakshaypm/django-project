var classgrade_1_1serializer_1_1MarkSerializer_1_1Meta =
[
    [ "fields", "classgrade_1_1serializer_1_1MarkSerializer_1_1Meta.html#aba4a6168ec01581ad4b745f530a1c521", null ],
    [ "model", "classgrade_1_1serializer_1_1MarkSerializer_1_1Meta.html#aab073eb5c973dcf8bfd1b505b97b77f4", null ]
];