var classroom_2models_8py =
[
    [ "classroom.models.Classroom", "classclassroom_1_1models_1_1Classroom.html", "classclassroom_1_1models_1_1Classroom" ]
];