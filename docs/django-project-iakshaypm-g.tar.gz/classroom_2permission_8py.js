var classroom_2permission_8py =
[
    [ "classroom.permission.IsManagement", "classclassroom_1_1permission_1_1IsManagement.html", "classclassroom_1_1permission_1_1IsManagement" ],
    [ "classroom.permission.IsTeacher", "classclassroom_1_1permission_1_1IsTeacher.html", "classclassroom_1_1permission_1_1IsTeacher" ]
];