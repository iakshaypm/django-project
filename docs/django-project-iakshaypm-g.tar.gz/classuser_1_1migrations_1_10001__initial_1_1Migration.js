var classuser_1_1migrations_1_10001__initial_1_1Migration =
[
    [ "dependencies", "classuser_1_1migrations_1_10001__initial_1_1Migration.html#a91cbe0533e9bc83354113293696732ee", null ],
    [ "initial", "classuser_1_1migrations_1_10001__initial_1_1Migration.html#a6411c9665bed9093e13305438871a7b0", null ],
    [ "operations", "classuser_1_1migrations_1_10001__initial_1_1Migration.html#a558a440b0f887d1afd139de308fa18ac", null ]
];