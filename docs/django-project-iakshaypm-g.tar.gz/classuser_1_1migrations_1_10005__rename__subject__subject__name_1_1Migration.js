var classuser_1_1migrations_1_10005__rename__subject__subject__name_1_1Migration =
[
    [ "dependencies", "classuser_1_1migrations_1_10005__rename__subject__subject__name_1_1Migration.html#a8c794eb10ccf3217d73aa057b7784ade", null ],
    [ "operations", "classuser_1_1migrations_1_10005__rename__subject__subject__name_1_1Migration.html#aa0fb9fd9d4abee0fd94aba963270ca07", null ]
];