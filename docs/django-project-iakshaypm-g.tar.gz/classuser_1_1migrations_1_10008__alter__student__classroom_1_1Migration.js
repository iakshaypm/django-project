var classuser_1_1migrations_1_10008__alter__student__classroom_1_1Migration =
[
    [ "dependencies", "classuser_1_1migrations_1_10008__alter__student__classroom_1_1Migration.html#a00cc7946168ad9d281995afe349bd88f", null ],
    [ "operations", "classuser_1_1migrations_1_10008__alter__student__classroom_1_1Migration.html#a1006aadc64446bf935526203fca3787c", null ]
];