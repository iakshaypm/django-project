var classuser_1_1migrations_1_10009__alter__account__user__type__parent__student__parent_1_1Migration =
[
    [ "dependencies", "classuser_1_1migrations_1_10009__alter__account__user__type__parent__student__parent_1_1Migration.html#a57ea729d71c9b1896dd214eec13258f4", null ],
    [ "operations", "classuser_1_1migrations_1_10009__alter__account__user__type__parent__student__parent_1_1Migration.html#a8ea3fb3a3ef51488b40995667f24b410", null ]
];