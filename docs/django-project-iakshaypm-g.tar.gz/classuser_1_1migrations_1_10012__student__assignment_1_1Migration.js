var classuser_1_1migrations_1_10012__student__assignment_1_1Migration =
[
    [ "dependencies", "classuser_1_1migrations_1_10012__student__assignment_1_1Migration.html#a192ba33b41dd612742096f00963b0f2f", null ],
    [ "operations", "classuser_1_1migrations_1_10012__student__assignment_1_1Migration.html#a65812d06b6467a198a19f21c4937c9b0", null ]
];