var classuser_1_1models_1_1MyAccountManager =
[
    [ "create_superuser", "classuser_1_1models_1_1MyAccountManager.html#a2603acb3375d85bf8c04c6e7af4c77d8", null ],
    [ "create_user", "classuser_1_1models_1_1MyAccountManager.html#a90a529083cbe05ac69b6cf4916a284c1", null ]
];