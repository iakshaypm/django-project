var classuser_1_1models_1_1Student =
[
    [ "assignment", "classuser_1_1models_1_1Student.html#ad5b70e855fa79333ed7304b19a5eb24f", null ],
    [ "classroom", "classuser_1_1models_1_1Student.html#a27a9e04d59c551cfa924771490543502", null ],
    [ "date_of_birth", "classuser_1_1models_1_1Student.html#a5b0ac817a79a8db20b17a2119b3cae82", null ],
    [ "department", "classuser_1_1models_1_1Student.html#a9efd9e529c29f373f7dac3d0693eeb82", null ],
    [ "location", "classuser_1_1models_1_1Student.html#a011d649d717424a033c59bd43698a6a2", null ],
    [ "parent", "classuser_1_1models_1_1Student.html#a3b636063f2ff7e32e3ac78b760d881fc", null ],
    [ "user", "classuser_1_1models_1_1Student.html#ae03c98ae686d6b4414cbfae4a41ef8f0", null ]
];