var classuser_1_1models_1_1Teacher =
[
    [ "classroom", "classuser_1_1models_1_1Teacher.html#a885c261420f10be895776de11797a9de", null ],
    [ "department", "classuser_1_1models_1_1Teacher.html#af8468a724deb9b3d688e3e8c4c19bb76", null ],
    [ "subject", "classuser_1_1models_1_1Teacher.html#ada5c4c1132cdf33f0dd496d496dd5f28", null ],
    [ "user", "classuser_1_1models_1_1Teacher.html#a39a70adae1575b3e9a06182aeb4bd335", null ]
];