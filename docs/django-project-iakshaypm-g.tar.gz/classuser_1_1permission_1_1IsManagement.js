var classuser_1_1permission_1_1IsManagement =
[
    [ "has_permission", "classuser_1_1permission_1_1IsManagement.html#a3a139cc7e08845c9594ac08cd68712be", null ]
];