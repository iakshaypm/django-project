var classuser_1_1serializers_1_1StudentAttendanceSerializer =
[
    [ "Meta", "classuser_1_1serializers_1_1StudentAttendanceSerializer_1_1Meta.html", "classuser_1_1serializers_1_1StudentAttendanceSerializer_1_1Meta" ]
];