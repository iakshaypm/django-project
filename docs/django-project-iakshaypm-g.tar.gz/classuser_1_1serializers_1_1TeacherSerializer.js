var classuser_1_1serializers_1_1TeacherSerializer =
[
    [ "Meta", "classuser_1_1serializers_1_1TeacherSerializer_1_1Meta.html", "classuser_1_1serializers_1_1TeacherSerializer_1_1Meta" ],
    [ "validate", "classuser_1_1serializers_1_1TeacherSerializer.html#a145bd3e82fc1105628dbd649937ae4e5", null ]
];