var classuser_1_1serializers_1_1UserSerializer =
[
    [ "Meta", "classuser_1_1serializers_1_1UserSerializer_1_1Meta.html", "classuser_1_1serializers_1_1UserSerializer_1_1Meta" ],
    [ "create", "classuser_1_1serializers_1_1UserSerializer.html#af9766e27952b92ae23dd1db889393f11", null ],
    [ "validate", "classuser_1_1serializers_1_1UserSerializer.html#a073ac4174745351c47ab7ca9c765b8e2", null ],
    [ "confirm_password", "classuser_1_1serializers_1_1UserSerializer.html#a8272c3ff659aa68f1039d66c9b767e72", null ]
];