var classuser_1_1serializers_1_1UserSerializer_1_1Meta =
[
    [ "extra_kwargs", "classuser_1_1serializers_1_1UserSerializer_1_1Meta.html#aeddf90a080f763483ed83fd87e92059a", null ],
    [ "fields", "classuser_1_1serializers_1_1UserSerializer_1_1Meta.html#a4ca3f8d705a137a0028afcda6aec1236", null ],
    [ "model", "classuser_1_1serializers_1_1UserSerializer_1_1Meta.html#a1b72102e056c5cabb2784b65a1ba4b30", null ]
];