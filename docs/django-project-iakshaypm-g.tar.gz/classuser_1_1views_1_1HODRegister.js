var classuser_1_1views_1_1HODRegister =
[
    [ "post", "classuser_1_1views_1_1HODRegister.html#a7ed2e1d216e255d04761926769571ab1", null ],
    [ "permission_classes", "classuser_1_1views_1_1HODRegister.html#aa920af6f2d36ca5607ec36f0272e64db", null ]
];