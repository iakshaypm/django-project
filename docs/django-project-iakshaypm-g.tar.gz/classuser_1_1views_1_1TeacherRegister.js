var classuser_1_1views_1_1TeacherRegister =
[
    [ "post", "classuser_1_1views_1_1TeacherRegister.html#a66b7ba9f9905438991c18dd699c38c09", null ],
    [ "permission_classes", "classuser_1_1views_1_1TeacherRegister.html#a97de193fa1a57d9e3ae968d4dbd7c041", null ]
];