var classwebhooks_1_1views_1_1TelegramWebhook =
[
    [ "post", "classwebhooks_1_1views_1_1TelegramWebhook.html#ad68eb579ee543296a4711a5053b0e69e", null ],
    [ "permission_classes", "classwebhooks_1_1views_1_1TelegramWebhook.html#a2f3d2c97e5d09c73dcc15d15eeb2bf7c", null ]
];