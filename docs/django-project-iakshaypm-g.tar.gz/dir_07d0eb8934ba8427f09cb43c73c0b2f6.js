var dir_07d0eb8934ba8427f09cb43c73c0b2f6 =
[
    [ "0001_initial.py", "grade_2migrations_20001__initial_8py.html", "grade_2migrations_20001__initial_8py" ],
    [ "0002_alter_mark_student_alter_mark_teacher.py", "0002__alter__mark__student__alter__mark__teacher_8py.html", "0002__alter__mark__student__alter__mark__teacher_8py" ],
    [ "0003_alter_mark_student_alter_mark_teacher.py", "0003__alter__mark__student__alter__mark__teacher_8py.html", "0003__alter__mark__student__alter__mark__teacher_8py" ],
    [ "0004_alter_mark_student.py", "0004__alter__mark__student_8py.html", "0004__alter__mark__student_8py" ],
    [ "__init__.py", "grade_2migrations_2____init_____8py.html", null ]
];