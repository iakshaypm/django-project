var dir_4649b9461b7228cdc7438f00ff8ca9f7 =
[
    [ "__init__.py", "college_2____init_____8py.html", null ],
    [ "asgi.py", "asgi_8py.html", "asgi_8py" ],
    [ "assignment.py", "assignment_8py.html", "assignment_8py" ],
    [ "celery.py", "celery_8py.html", "celery_8py" ],
    [ "file_type_detector.py", "file__type__detector_8py.html", "file__type__detector_8py" ],
    [ "urls.py", "college_2urls_8py.html", "college_2urls_8py" ],
    [ "wsgi.py", "wsgi_8py.html", "wsgi_8py" ]
];