var dir_750cb86727cffb887c0c8e837c38ba1d =
[
    [ "migrations", "dir_c34cc6a17b8fdecf9a99abbd23633c06.html", "dir_c34cc6a17b8fdecf9a99abbd23633c06" ],
    [ "__init__.py", "exchange_2____init_____8py.html", null ],
    [ "admin.py", "exchange_2admin_8py.html", "exchange_2admin_8py" ],
    [ "apps.py", "exchange_2apps_8py.html", "exchange_2apps_8py" ],
    [ "models.py", "exchange_2models_8py.html", "exchange_2models_8py" ],
    [ "permission.py", "exchange_2permission_8py.html", "exchange_2permission_8py" ],
    [ "serializers.py", "exchange_2serializers_8py.html", "exchange_2serializers_8py" ],
    [ "signals.py", "exchange_2signals_8py.html", "exchange_2signals_8py" ],
    [ "tests.py", "exchange_2tests_8py.html", null ],
    [ "urls.py", "exchange_2urls_8py.html", "exchange_2urls_8py" ],
    [ "views.py", "exchange_2views_8py.html", "exchange_2views_8py" ]
];