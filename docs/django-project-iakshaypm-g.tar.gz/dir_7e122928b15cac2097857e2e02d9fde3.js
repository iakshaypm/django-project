var dir_7e122928b15cac2097857e2e02d9fde3 =
[
    [ "0001_initial.py", "chat_2migrations_20001__initial_8py.html", "chat_2migrations_20001__initial_8py" ],
    [ "0002_alter_room_name.py", "0002__alter__room__name_8py.html", "0002__alter__room__name_8py" ],
    [ "0003_room_created_by_alter_room_online.py", "0003__room__created__by__alter__room__online_8py.html", "0003__room__created__by__alter__room__online_8py" ],
    [ "0004_room_type.py", "0004__room__type_8py.html", "0004__room__type_8py" ],
    [ "__init__.py", "chat_2migrations_2____init_____8py.html", null ]
];