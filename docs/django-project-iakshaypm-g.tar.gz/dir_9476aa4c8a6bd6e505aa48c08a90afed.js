var dir_9476aa4c8a6bd6e505aa48c08a90afed =
[
    [ "__init__.py", "webhooks_2management_2commands_2____init_____8py.html", null ],
    [ "set_telegram_webhook.py", "set__telegram__webhook_8py.html", "set__telegram__webhook_8py" ]
];