var dir_a7039c525c66631d6a920e9aee74afc2 =
[
    [ "migrations", "dir_55739097199ccb14f2dd6a7f55398c57.html", "dir_55739097199ccb14f2dd6a7f55398c57" ],
    [ "__init__.py", "assignment_2____init_____8py.html", null ],
    [ "admin.py", "assignment_2admin_8py.html", null ],
    [ "apps.py", "assignment_2apps_8py.html", "assignment_2apps_8py" ],
    [ "models.py", "assignment_2models_8py.html", "assignment_2models_8py" ],
    [ "serializers.py", "assignment_2serializers_8py.html", "assignment_2serializers_8py" ],
    [ "tests.py", "assignment_2tests_8py.html", null ],
    [ "urls.py", "assignment_2urls_8py.html", "assignment_2urls_8py" ],
    [ "views.py", "assignment_2views_8py.html", "assignment_2views_8py" ]
];