var exam_2apps_8py =
[
    [ "exam.apps.ExamConfig", "classexam_1_1apps_1_1ExamConfig.html", "classexam_1_1apps_1_1ExamConfig" ]
];