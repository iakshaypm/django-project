var exam_2migrations_20001__initial_8py =
[
    [ "exam.migrations.0001_initial.Migration", "classexam_1_1migrations_1_10001__initial_1_1Migration.html", "classexam_1_1migrations_1_10001__initial_1_1Migration" ]
];