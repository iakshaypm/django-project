var exam_2urls_8py =
[
    [ "app_name", "exam_2urls_8py.html#a72cf6cfbee11855ab7d29ef2123adab6", null ],
    [ "urlpatterns", "exam_2urls_8py.html#a8383dd92b788f7b6fc6ddea686a26fea", null ]
];