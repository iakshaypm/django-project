var file__type__detector_8py =
[
    [ "run_linter", "file__type__detector_8py.html#a09e6f3d9243faf2b5eba28a8012968af", null ],
    [ "linters", "file__type__detector_8py.html#a4abdd44e1f1942108ebc378e66fd6acc", null ]
];