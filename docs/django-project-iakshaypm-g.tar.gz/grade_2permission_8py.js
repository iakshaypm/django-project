var grade_2permission_8py =
[
    [ "grade.permission.IsStudent", "classgrade_1_1permission_1_1IsStudent.html", "classgrade_1_1permission_1_1IsStudent" ],
    [ "grade.permission.IsTeacher", "classgrade_1_1permission_1_1IsTeacher.html", "classgrade_1_1permission_1_1IsTeacher" ],
    [ "grade.permission.CanAccessComment", "classgrade_1_1permission_1_1CanAccessComment.html", "classgrade_1_1permission_1_1CanAccessComment" ],
    [ "grade.permission.CanUpvote", "classgrade_1_1permission_1_1CanUpvote.html", "classgrade_1_1permission_1_1CanUpvote" ],
    [ "grade.permission.CanRemoveUpvote", "classgrade_1_1permission_1_1CanRemoveUpvote.html", "classgrade_1_1permission_1_1CanRemoveUpvote" ]
];