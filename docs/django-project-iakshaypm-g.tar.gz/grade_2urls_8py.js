var grade_2urls_8py =
[
    [ "app_name", "grade_2urls_8py.html#a9cd0dbf6c10bc9a843f0efb3c8b39712", null ],
    [ "urlpatterns", "grade_2urls_8py.html#a1fbcc5f1316c75c3201b5c9a4f31822f", null ]
];