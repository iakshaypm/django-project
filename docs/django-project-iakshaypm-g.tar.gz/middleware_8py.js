var middleware_8py =
[
    [ "chat.middleware.TokenAuthMiddleware", "classchat_1_1middleware_1_1TokenAuthMiddleware.html", "classchat_1_1middleware_1_1TokenAuthMiddleware" ]
];