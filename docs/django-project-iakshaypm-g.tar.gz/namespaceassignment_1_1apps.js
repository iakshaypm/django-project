var namespaceassignment_1_1apps =
[
    [ "AssignmentConfig", "classassignment_1_1apps_1_1AssignmentConfig.html", "classassignment_1_1apps_1_1AssignmentConfig" ]
];