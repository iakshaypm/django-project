var namespaceassignment_1_1migrations =
[
    [ "0001_initial", "namespaceassignment_1_1migrations_1_10001__initial.html", "namespaceassignment_1_1migrations_1_10001__initial" ]
];