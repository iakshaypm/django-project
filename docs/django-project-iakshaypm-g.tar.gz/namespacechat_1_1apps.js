var namespacechat_1_1apps =
[
    [ "ChatConfig", "classchat_1_1apps_1_1ChatConfig.html", "classchat_1_1apps_1_1ChatConfig" ]
];