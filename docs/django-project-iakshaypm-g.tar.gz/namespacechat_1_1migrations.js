var namespacechat_1_1migrations =
[
    [ "0001_initial", "namespacechat_1_1migrations_1_10001__initial.html", "namespacechat_1_1migrations_1_10001__initial" ],
    [ "0002_alter_room_name", "namespacechat_1_1migrations_1_10002__alter__room__name.html", "namespacechat_1_1migrations_1_10002__alter__room__name" ],
    [ "0003_room_created_by_alter_room_online", "namespacechat_1_1migrations_1_10003__room__created__by__alter__room__online.html", "namespacechat_1_1migrations_1_10003__room__created__by__alter__room__online" ],
    [ "0004_room_type", "namespacechat_1_1migrations_1_10004__room__type.html", "namespacechat_1_1migrations_1_10004__room__type" ]
];