var namespacechat_1_1models =
[
    [ "Message", "classchat_1_1models_1_1Message.html", "classchat_1_1models_1_1Message" ],
    [ "Room", "classchat_1_1models_1_1Room.html", "classchat_1_1models_1_1Room" ]
];