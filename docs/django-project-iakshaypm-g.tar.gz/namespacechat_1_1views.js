var namespacechat_1_1views =
[
    [ "CreateRoomView", "classchat_1_1views_1_1CreateRoomView.html", "classchat_1_1views_1_1CreateRoomView" ],
    [ "index_view", "namespacechat_1_1views.html#a83eb6b69744232e6d709bb3ecfb3d97d", null ]
];