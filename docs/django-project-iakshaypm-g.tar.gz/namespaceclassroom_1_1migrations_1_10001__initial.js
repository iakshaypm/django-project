var namespaceclassroom_1_1migrations_1_10001__initial =
[
    [ "Migration", "classclassroom_1_1migrations_1_10001__initial_1_1Migration.html", "classclassroom_1_1migrations_1_10001__initial_1_1Migration" ]
];