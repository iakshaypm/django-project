var namespaceclassroom_1_1migrations_1_10002__alter__classroom__name =
[
    [ "Migration", "classclassroom_1_1migrations_1_10002__alter__classroom__name_1_1Migration.html", "classclassroom_1_1migrations_1_10002__alter__classroom__name_1_1Migration" ]
];