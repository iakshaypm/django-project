var namespaceclassroom_1_1permission =
[
    [ "IsManagement", "classclassroom_1_1permission_1_1IsManagement.html", "classclassroom_1_1permission_1_1IsManagement" ],
    [ "IsTeacher", "classclassroom_1_1permission_1_1IsTeacher.html", "classclassroom_1_1permission_1_1IsTeacher" ]
];