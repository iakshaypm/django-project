var namespaceexam =
[
    [ "admin", "namespaceexam_1_1admin.html", null ],
    [ "apps", "namespaceexam_1_1apps.html", "namespaceexam_1_1apps" ],
    [ "migrations", "namespaceexam_1_1migrations.html", "namespaceexam_1_1migrations" ],
    [ "models", "namespaceexam_1_1models.html", "namespaceexam_1_1models" ],
    [ "serializers", "namespaceexam_1_1serializers.html", "namespaceexam_1_1serializers" ],
    [ "tests", "namespaceexam_1_1tests.html", null ],
    [ "urls", "namespaceexam_1_1urls.html", [
      [ "app_name", "namespaceexam_1_1urls.html#a72cf6cfbee11855ab7d29ef2123adab6", null ],
      [ "urlpatterns", "namespaceexam_1_1urls.html#a8383dd92b788f7b6fc6ddea686a26fea", null ]
    ] ],
    [ "views", "namespaceexam_1_1views.html", "namespaceexam_1_1views" ]
];