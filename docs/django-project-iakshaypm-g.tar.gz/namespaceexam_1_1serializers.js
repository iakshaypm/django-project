var namespaceexam_1_1serializers =
[
    [ "ExamSerializer", "classexam_1_1serializers_1_1ExamSerializer.html", "classexam_1_1serializers_1_1ExamSerializer" ]
];