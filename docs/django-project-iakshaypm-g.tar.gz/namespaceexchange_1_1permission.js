var namespaceexchange_1_1permission =
[
    [ "CanAccessComment", "classexchange_1_1permission_1_1CanAccessComment.html", "classexchange_1_1permission_1_1CanAccessComment" ],
    [ "CanAddComment", "classexchange_1_1permission_1_1CanAddComment.html", "classexchange_1_1permission_1_1CanAddComment" ],
    [ "CanRemoveUpvote", "classexchange_1_1permission_1_1CanRemoveUpvote.html", "classexchange_1_1permission_1_1CanRemoveUpvote" ],
    [ "CanUpvote", "classexchange_1_1permission_1_1CanUpvote.html", "classexchange_1_1permission_1_1CanUpvote" ],
    [ "IsStudent", "classexchange_1_1permission_1_1IsStudent.html", "classexchange_1_1permission_1_1IsStudent" ],
    [ "IsTeacher", "classexchange_1_1permission_1_1IsTeacher.html", "classexchange_1_1permission_1_1IsTeacher" ]
];