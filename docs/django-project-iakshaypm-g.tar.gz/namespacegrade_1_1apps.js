var namespacegrade_1_1apps =
[
    [ "GradeConfig", "classgrade_1_1apps_1_1GradeConfig.html", "classgrade_1_1apps_1_1GradeConfig" ]
];