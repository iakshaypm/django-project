var namespaceuser_1_1migrations_1_10003__alter__account__is__staff =
[
    [ "Migration", "classuser_1_1migrations_1_10003__alter__account__is__staff_1_1Migration.html", "classuser_1_1migrations_1_10003__alter__account__is__staff_1_1Migration" ]
];