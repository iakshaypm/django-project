var namespaceuser_1_1migrations_1_10008__alter__student__classroom =
[
    [ "Migration", "classuser_1_1migrations_1_10008__alter__student__classroom_1_1Migration.html", "classuser_1_1migrations_1_10008__alter__student__classroom_1_1Migration" ]
];