var namespaceuser_1_1serializers =
[
    [ "ClassroomSerializer", "classuser_1_1serializers_1_1ClassroomSerializer.html", "classuser_1_1serializers_1_1ClassroomSerializer" ],
    [ "HODSerializer", "classuser_1_1serializers_1_1HODSerializer.html", "classuser_1_1serializers_1_1HODSerializer" ],
    [ "MarkSerializer", "classuser_1_1serializers_1_1MarkSerializer.html", "classuser_1_1serializers_1_1MarkSerializer" ],
    [ "StudentAttendanceSerializer", "classuser_1_1serializers_1_1StudentAttendanceSerializer.html", "classuser_1_1serializers_1_1StudentAttendanceSerializer" ],
    [ "StudentSerializer", "classuser_1_1serializers_1_1StudentSerializer.html", "classuser_1_1serializers_1_1StudentSerializer" ],
    [ "StudentViewSerializer", "classuser_1_1serializers_1_1StudentViewSerializer.html", "classuser_1_1serializers_1_1StudentViewSerializer" ],
    [ "TeacherSerializer", "classuser_1_1serializers_1_1TeacherSerializer.html", "classuser_1_1serializers_1_1TeacherSerializer" ],
    [ "UserSerializer", "classuser_1_1serializers_1_1UserSerializer.html", "classuser_1_1serializers_1_1UserSerializer" ]
];