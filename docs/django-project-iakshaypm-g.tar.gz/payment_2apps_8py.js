var payment_2apps_8py =
[
    [ "payment.apps.PaymentConfig", "classpayment_1_1apps_1_1PaymentConfig.html", "classpayment_1_1apps_1_1PaymentConfig" ]
];