var routing_8py =
[
    [ "websocket_urlpatterns", "routing_8py.html#a9079064cf5cc6236e957a9958bdaa47f", null ]
];