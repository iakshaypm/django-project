var searchData=
[
  ['baseuseradmin_0',['BaseUserAdmin',['../classBaseUserAdmin.html',1,'']]]
];
