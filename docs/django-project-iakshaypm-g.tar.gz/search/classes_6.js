var searchData=
[
  ['ishod_0',['IsHOD',['../classuser_1_1permission_1_1IsHOD.html',1,'user::permission']]],
  ['ismanagement_1',['IsManagement',['../classclassroom_1_1permission_1_1IsManagement.html',1,'classroom.permission.IsManagement'],['../classuser_1_1permission_1_1IsManagement.html',1,'user.permission.IsManagement']]],
  ['isparent_2',['IsParent',['../classuser_1_1permission_1_1IsParent.html',1,'user::permission']]],
  ['isstudent_3',['IsStudent',['../classattendance_1_1permission_1_1IsStudent.html',1,'attendance.permission.IsStudent'],['../classexchange_1_1permission_1_1IsStudent.html',1,'exchange.permission.IsStudent'],['../classgrade_1_1permission_1_1IsStudent.html',1,'grade.permission.IsStudent'],['../classuser_1_1permission_1_1IsStudent.html',1,'user.permission.IsStudent']]],
  ['isteacher_4',['IsTeacher',['../classattendance_1_1permission_1_1IsTeacher.html',1,'attendance.permission.IsTeacher'],['../classclassroom_1_1permission_1_1IsTeacher.html',1,'classroom.permission.IsTeacher'],['../classexchange_1_1permission_1_1IsTeacher.html',1,'exchange.permission.IsTeacher'],['../classgrade_1_1permission_1_1IsTeacher.html',1,'grade.permission.IsTeacher'],['../classuser_1_1permission_1_1IsTeacher.html',1,'user.permission.IsTeacher']]]
];
