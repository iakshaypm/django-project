var searchData=
[
  ['registerview_0',['RegisterView',['../classuser_1_1views_1_1RegisterView.html',1,'user::views']]],
  ['room_1',['Room',['../classchat_1_1models_1_1Room.html',1,'chat::models']]],
  ['roomserializer_2',['RoomSerializer',['../classchat_1_1serializers_1_1RoomSerializer.html',1,'chat::serializers']]]
];
