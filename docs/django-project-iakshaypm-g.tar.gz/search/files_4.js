var searchData=
[
  ['file_5ftype_5fdetector_2epy_0',['file_type_detector.py',['../file__type__detector_8py.html',1,'']]]
];
