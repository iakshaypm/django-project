var searchData=
[
  ['manage_2epy_0',['manage.py',['../manage_8py.html',1,'']]],
  ['middleware_2epy_1',['middleware.py',['../middleware_8py.html',1,'']]],
  ['models_2epy_2',['models.py',['../assignment_2models_8py.html',1,'(Global Namespace)'],['../attendance_2models_8py.html',1,'(Global Namespace)'],['../chat_2models_8py.html',1,'(Global Namespace)'],['../classroom_2models_8py.html',1,'(Global Namespace)'],['../exam_2models_8py.html',1,'(Global Namespace)'],['../exchange_2models_8py.html',1,'(Global Namespace)'],['../grade_2models_8py.html',1,'(Global Namespace)'],['../payment_2models_8py.html',1,'(Global Namespace)'],['../user_2models_8py.html',1,'(Global Namespace)'],['../webhooks_2models_8py.html',1,'(Global Namespace)']]],
  ['mybackend_2epy_3',['MyBackend.py',['../MyBackend_8py.html',1,'']]]
];
