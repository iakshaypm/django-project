var searchData=
[
  ['permission_2epy_0',['permission.py',['../attendance_2permission_8py.html',1,'(Global Namespace)'],['../chat_2permission_8py.html',1,'(Global Namespace)'],['../classroom_2permission_8py.html',1,'(Global Namespace)'],['../exchange_2permission_8py.html',1,'(Global Namespace)'],['../grade_2permission_8py.html',1,'(Global Namespace)'],['../user_2permission_8py.html',1,'(Global Namespace)']]]
];
