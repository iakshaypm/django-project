var searchData=
[
  ['serializer_2epy_0',['serializer.py',['../attendance_2serializer_8py.html',1,'(Global Namespace)'],['../grade_2serializer_8py.html',1,'(Global Namespace)']]],
  ['serializers_2epy_1',['serializers.py',['../assignment_2serializers_8py.html',1,'(Global Namespace)'],['../chat_2serializers_8py.html',1,'(Global Namespace)'],['../classroom_2serializers_8py.html',1,'(Global Namespace)'],['../exam_2serializers_8py.html',1,'(Global Namespace)'],['../exchange_2serializers_8py.html',1,'(Global Namespace)'],['../user_2serializers_8py.html',1,'(Global Namespace)']]],
  ['set_5ftelegram_5fwebhook_2epy_2',['set_telegram_webhook.py',['../set__telegram__webhook_8py.html',1,'']]],
  ['signals_2epy_3',['signals.py',['../exchange_2signals_8py.html',1,'(Global Namespace)'],['../user_2signals_8py.html',1,'(Global Namespace)']]]
];
