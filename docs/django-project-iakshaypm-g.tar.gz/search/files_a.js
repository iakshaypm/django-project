var searchData=
[
  ['urls_2epy_0',['urls.py',['../assignment_2urls_8py.html',1,'(Global Namespace)'],['../attendance_2urls_8py.html',1,'(Global Namespace)'],['../chat_2urls_8py.html',1,'(Global Namespace)'],['../classroom_2urls_8py.html',1,'(Global Namespace)'],['../college_2urls_8py.html',1,'(Global Namespace)'],['../exam_2urls_8py.html',1,'(Global Namespace)'],['../exchange_2urls_8py.html',1,'(Global Namespace)'],['../grade_2urls_8py.html',1,'(Global Namespace)'],['../payment_2urls_8py.html',1,'(Global Namespace)'],['../user_2urls_8py.html',1,'(Global Namespace)'],['../webhooks_2urls_8py.html',1,'(Global Namespace)']]]
];
