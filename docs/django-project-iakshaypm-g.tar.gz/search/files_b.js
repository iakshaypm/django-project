var searchData=
[
  ['views_2epy_0',['views.py',['../assignment_2views_8py.html',1,'(Global Namespace)'],['../attendance_2views_8py.html',1,'(Global Namespace)'],['../chat_2views_8py.html',1,'(Global Namespace)'],['../classroom_2views_8py.html',1,'(Global Namespace)'],['../exam_2views_8py.html',1,'(Global Namespace)'],['../exchange_2views_8py.html',1,'(Global Namespace)'],['../grade_2views_8py.html',1,'(Global Namespace)'],['../payment_2views_8py.html',1,'(Global Namespace)'],['../user_2views_8py.html',1,'(Global Namespace)'],['../webhooks_2views_8py.html',1,'(Global Namespace)']]]
];
