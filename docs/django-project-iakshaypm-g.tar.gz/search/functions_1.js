var searchData=
[
  ['add_5farguments_0',['add_arguments',['../classwebhooks_1_1management_1_1commands_1_1set__telegram__webhook_1_1Command.html#a39404b6753d59408490cca264b7274c2',1,'webhooks::management::commands::set_telegram_webhook::Command']]],
  ['assignnewassignment_1',['assignNewAssignment',['../namespacecollege_1_1assignment.html#a2e9a2823fe1c92b647de3027bac48b69',1,'college::assignment']]],
  ['authenticate_2',['authenticate',['../classuser_1_1MyBackend_1_1CustomBackend.html#a08275ac38e0870620f11d2f0ad9ac420',1,'user::MyBackend::CustomBackend']]]
];
