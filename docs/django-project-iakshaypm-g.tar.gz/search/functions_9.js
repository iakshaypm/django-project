var searchData=
[
  ['main_0',['main',['../namespacemanage.html#a0ac64ea81648f42d6a49d76da894eaf4',1,'manage']]]
];
