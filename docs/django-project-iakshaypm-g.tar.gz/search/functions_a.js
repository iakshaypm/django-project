var searchData=
[
  ['notify_5fadmin_0',['notify_admin',['../namespaceexchange_1_1signals.html#a873621cd603607b617ec327c50f8d4b7',1,'exchange.signals.notify_admin()'],['../namespaceuser_1_1signals.html#a5a15b9f444d79db25836abba020571c7',1,'user.signals.notify_admin()']]]
];
