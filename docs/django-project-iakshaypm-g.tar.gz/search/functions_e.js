var searchData=
[
  ['test_5fadding_5fstudent_5fattendance_0',['test_adding_student_attendance',['../classattendance_1_1tests_1_1test__attendance_1_1TestMainAttendance.html#a0a4d32959442ec0247d3bad62fc17931',1,'attendance::tests::test_attendance::TestMainAttendance']]],
  ['test_5fcreate_5fuser_5fwith_5femail_5fsuccessful_1',['test_create_user_with_email_successful',['../classuser_1_1tests_1_1ModelTest.html#a1da68cfad4c247580f21f444d9715f1d',1,'user::tests::ModelTest']]],
  ['test_5fcreating_5fmain_5fattendance_2',['test_creating_main_attendance',['../classattendance_1_1tests_1_1test__attendance_1_1TestMainAttendance.html#ac73194fb12e6a5e5791245ccaa374066',1,'attendance::tests::test_attendance::TestMainAttendance']]]
];
