var searchData=
[
  ['tag_0',['tag',['../classexchange_1_1models_1_1Question.html#a850b6440865a49b91b3da44ce9f1a5f4',1,'exchange::models::Question']]],
  ['teacher_1',['teacher',['../classattendance_1_1models_1_1TeacherAttendance.html#a6b5a740c159356ccabc1186bf8d48f4b',1,'attendance.models.TeacherAttendance.teacher'],['../classattendance_1_1serializer_1_1TeacherAttendanceSerializer.html#a1e3ceb8927e52aead6c30a232a2d011e',1,'attendance.serializer.TeacherAttendanceSerializer.teacher'],['../classattendance_1_1tests_1_1test__attendance_1_1TestMainAttendance.html#ad8859c26e0329b5f20df665f1b841a8a',1,'attendance.tests.test_attendance.TestMainAttendance.teacher'],['../classgrade_1_1models_1_1Mark.html#abeacb4a549feba7fec2aaa3bdbe4bd07',1,'grade.models.Mark.teacher']]],
  ['timestamp_2',['timestamp',['../classchat_1_1models_1_1Message.html#aa51021e71d8e95498c2fdad535647a70',1,'chat::models::Message']]],
  ['title_3',['title',['../classexchange_1_1models_1_1Question.html#a50625eabad28b8a5a616b789f188b1b4',1,'exchange::models::Question']]],
  ['total_5fstrength_4',['total_strength',['../classclassroom_1_1models_1_1Classroom.html#abd5e7afd8b036f8f3e73b11898e095a8',1,'classroom::models::Classroom']]],
  ['type_5',['type',['../classassignment_1_1models_1_1Assignment.html#a29b1cd7d6712e9f921ae8c0f7f07ae72',1,'assignment.models.Assignment.type'],['../classchat_1_1models_1_1Room.html#a97e61211282eb939cf41d2e70aaa4921',1,'chat.models.Room.type']]]
];
