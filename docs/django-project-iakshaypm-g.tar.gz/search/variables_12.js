var searchData=
[
  ['webhook_5fsecret_0',['webhook_secret',['../namespacepayment_1_1views.html#abcc29e964087bf86bd1fa16f66d9ffea',1,'payment::views']]],
  ['websocket_5furlpatterns_1',['websocket_urlpatterns',['../namespacechat_1_1routing.html#a9079064cf5cc6236e957a9958bdaa47f',1,'chat::routing']]]
];
