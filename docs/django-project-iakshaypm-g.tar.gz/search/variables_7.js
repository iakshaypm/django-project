var searchData=
[
  ['jwt_5fobject_0',['jwt_object',['../classchat_1_1middleware_1_1TokenAuthMiddleware.html#a26cbaf413fb7edd196593c61259f4cf4',1,'chat::middleware::TokenAuthMiddleware']]]
];
