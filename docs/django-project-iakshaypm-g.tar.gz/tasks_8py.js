var tasks_8py =
[
    [ "send_telegram_reply", "tasks_8py.html#a85c8a496121547fa4eec859d4763101c", null ]
];