var user_2models_8py =
[
    [ "user.models.MyAccountManager", "classuser_1_1models_1_1MyAccountManager.html", "classuser_1_1models_1_1MyAccountManager" ],
    [ "user.models.Account", "classuser_1_1models_1_1Account.html", "classuser_1_1models_1_1Account" ],
    [ "user.models.Student", "classuser_1_1models_1_1Student.html", "classuser_1_1models_1_1Student" ],
    [ "user.models.Subject", "classuser_1_1models_1_1Subject.html", "classuser_1_1models_1_1Subject" ],
    [ "user.models.Teacher", "classuser_1_1models_1_1Teacher.html", "classuser_1_1models_1_1Teacher" ],
    [ "user.models.HOD", "classuser_1_1models_1_1HOD.html", "classuser_1_1models_1_1HOD" ]
];