var user_2urls_8py =
[
    [ "app_name", "user_2urls_8py.html#a248e74c816eda6ab3bd391c1d9efc2f6", null ],
    [ "urlpatterns", "user_2urls_8py.html#a8f768fe416604807e9f185e87995c61a", null ]
];