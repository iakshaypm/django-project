var webhooks_2urls_8py =
[
    [ "app_name", "webhooks_2urls_8py.html#a040467f63e23242f1424ff30c6e109cf", null ],
    [ "urlpatterns", "webhooks_2urls_8py.html#abdf2a44ddd69a86af3032dc9ffefa986", null ]
];