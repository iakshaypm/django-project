var webhooks_2views_8py =
[
    [ "webhooks.views.TelegramWebhook", "classwebhooks_1_1views_1_1TelegramWebhook.html", "classwebhooks_1_1views_1_1TelegramWebhook" ]
];